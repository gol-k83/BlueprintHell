package controller;

import util.Constants;
import model.Port;
import model.Wire;

import java.util.ArrayList;
import java.util.List;

public class WireManager {
    private final List<Wire> wires;
    private double totalWireLengthUsed;
    //private final List<WireView> wires = new ArrayList<>();

    public WireManager() {
        this.wires = new ArrayList<>();
        this.totalWireLengthUsed = 0;

    }

    public boolean tryConnectPorts(Port toPort, Port fromPort) {

        if (toPort.getType() != Port.PortType.OUTPUT || fromPort.getType() != Port.PortType.INPUT)
            return false;
        if (toPort.getParentNode() == fromPort.getParentNode())
            return false;
        if (fromPort.getConnectedWire() != null || toPort.getConnectedWire() != null){
            System.out.println("⛔ یکی از پورت‌ها قبلاً متصل شده");
            return false;}
        if (!fromPort.isCompatibleWith(toPort.getCompatibleShape())) {
            System.out.println("⛔ پورت‌ها ناسازگار هستند");
            return false;
        }

        double wireLength = fromPort.getPosition().distanceTo(toPort.getPosition());
        if (totalWireLengthUsed + wireLength > Constants.TOTAL_AVAILABLE_WIRE_LENGTH){

        System.out.println(" ⛔طول سیم مجاز تمام شده!");
            return false;
        }


        Wire newWire = new Wire(fromPort, toPort);
        if (newWire == null) System.out.println("❌ newWire is null!");

        fromPort.setConnectedWire(newWire);
        toPort.setConnectedWire(newWire);
        wires.add(newWire);
        totalWireLengthUsed += wireLength;

        System.out.println("FromPort ID: " + fromPort.getId() + " → ToPort ID: " + toPort.getId());
        return true;

    }

    public Wire connectAndReturn(Port fromPort, Port toPort) {
        boolean success = tryConnectPorts(fromPort, toPort);
        System.out.println("❓ ا❓ ا❓ ا❓ ا❓ ا❓ ا❓ ا❓ اconnectAndReturn called. Wires size = " + wires.size());

        if (!success) return null;

        return wires.getLast();
        // آخرین سیم موفق ثبت‌شده
    }


    public void removeWire(Wire wire) {
        wires.remove(wire);
        totalWireLengthUsed -= wire.getLength();
        wire.getFromPort().setConnectedWire(null);
        wire.getToPort().setConnectedWire(null);
    }

    public List<Wire> getWires() {
        return wires;
    }

    public double getRemainingWireLength() {
        return Constants.TOTAL_AVAILABLE_WIRE_LENGTH - totalWireLengthUsed;
    }


    public List<Wire> getAll() {
        return wires;
    }
}

