// ✅ نسخه به‌روز‌شده draw در WireView برای رسم صحیح سیم‌ها و نقاط خم
package view;

import model.Port;
import model.Wire;
import util.Constants;
import util.Vector2D;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.util.List;

public class WireView {
    private final Wire wire;
    private Color color;

    public WireView(Wire wire) {
        this.wire = wire;
        this.color = Color.BLUE;
    }

    public void draw(Graphics2D g, GameStageView stage) {
        Port fromPort = wire.getFromPort();
        Port toPort = wire.getToPort();

        PortView fromView = stage.findPortView(fromPort);
        PortView toView = stage.findPortView(toPort);

        if (fromView == null || toView == null) return;

        List<Vector2D> controlPoints = wire.getAllControlPoints();

        g.setColor(color);
        g.setStroke(new BasicStroke(2));

        for (int i = 0; i < controlPoints.size() - 1; i++) {
            Point p1 = SwingUtilities.convertPoint(stage, controlPoints.get(i).toPoint(), stage);
            Point p2 = SwingUtilities.convertPoint(stage, controlPoints.get(i + 1).toPoint(), stage);

            g.drawLine(p1.x, p1.y, p2.x, p2.y);
            System.out.println("🟡 Segment from: " + p1 + " to " + p2);

            g.setColor(Color.MAGENTA);
            g.setStroke(new BasicStroke(3));
            g.drawLine(p1.x, p1.y, p2.x, p2.y);

        }







        // 🎯 نمایش نقاط خم به صورت دایره‌های قرمز
        g.setColor(Color.RED);
        for (Vector2D bend : wire.getBendPoints()) {
            Point bp = SwingUtilities.convertPoint(stage, bend.toPoint(), stage);
            int r = 8;
            Ellipse2D.Double circle = new Ellipse2D.Double(bp.x - r / 2.0, bp.y - r / 2.0, r, r);
            g.fill(circle);
        }
    }

    public boolean isNear(Point p) {
        List<Vector2D> all = wire.getAllControlPoints();
        for (int i = 0; i < all.size() - 1; i++) {
            Point a = all.get(i).toPoint();
            Point b = all.get(i + 1).toPoint();
            double dist = distancePointToSegment(p, a, b);
            if (dist < Constants.WIRE_HITBOX_RADIUS) return true;
        }
        return false;
    }

    private double distancePointToSegment(Point p, Point a, Point b) {
        double px = b.x - a.x;
        double py = b.y - a.y;
        double norm = px * px + py * py;
        if (norm == 0) return a.distance(p);
        double u = ((p.x - a.x) * px + (p.y - a.y) * py) / norm;
        u = Math.max(0, Math.min(1, u));
        double x = a.x + u * px;
        double y = a.y + u * py;
        double dx = x - p.x;
        double dy = y - p.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    public Wire getWire() {
        return wire;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }
}
