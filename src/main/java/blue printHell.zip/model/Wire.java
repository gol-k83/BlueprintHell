// ✅ نسخه نهایی Wire.java با بهینه‌سازی‌ها و رعایت نکات پیشرفته و سازگار با مکانیزم خم‌پذیری فاز دوم
package model;

import controller.StageManager;
import util.Vector2D;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Wire {
    private final Port fromPort;
    private final Port toPort;
    private final List<Packet> packetsOnWire;
    private final List<Vector2D> bendPoints;
    private int bendableSlots;

    public Wire(Port fromPort, Port toPort) {
        this.fromPort = fromPort;
        this.toPort = toPort;
        this.packetsOnWire = new LinkedList<>();
        this.bendPoints = new ArrayList<>();
        this.bendableSlots = 0;
    }

    public Port getFromPort() {
        return fromPort;
    }

    public Port getToPort() {
        return toPort;
    }

    public List<Vector2D> getBendPoints() {
        return bendPoints;
    }


    public int getRemainingBendSlots() {
        return bendableSlots - bendPoints.size();
    }

    public void purchaseBendSlot() {
        bendableSlots++;
    }

    public boolean canAddBendPoint() {
        return bendPoints.size() < bendableSlots;
    }

    public void addBendPoint(Vector2D point) {
        if (canAddBendPoint()) {
            bendPoints.add(point);
        }
    }

    public void moveBendPoint(int index, Vector2D newPosition) {
        if (index >= 0 && index < bendPoints.size()) {
            bendPoints.set(index, newPosition);
        }
    }

    public void clearBendPoints() {
        bendPoints.clear();
    }

    public List<Vector2D> getAllControlPoints() {
        List<Vector2D> points = new ArrayList<>();
        points.add(fromPort.getPosition());
        points.addAll(bendPoints);
        points.add(toPort.getPosition());
        return points;
    }

    public double getLength() {
        List<Vector2D> points = getAllControlPoints();
        if (points.size() < 2) return 0;
        double total = 0;
        for (int i = 0; i < points.size() - 1; i++) {
            total += points.get(i).distanceTo(points.get(i + 1));
        }
        return total;
    }

    public Vector2D getEffectiveDirection() {
        List<Vector2D> points = getAllControlPoints();
        if (points.size() < 2) return new Vector2D(0, 0);
        return points.get(1).subtract(points.get(0)).normalize();
    }

    public void addPacket(Packet packet) {
        if (!packetsOnWire.isEmpty()) return;
        packet.setPosition(fromPort.getPosition());
        packetsOnWire.add(packet);
    }

    public void update(double deltaTime) {
        packetsOnWire.removeIf(p -> {
            if (p.isLost()) {
                StageManager.getInstance().getTracker().addLost(p);
                return true;
            }
            return false;
        });

        List<Packet> delivered = new LinkedList<>();
        for (Packet packet : packetsOnWire) {
            packet.updateMovement(deltaTime);
            if (packet.getPosition().distanceTo(toPort.getPosition()) < 5.0) {
                delivered.add(packet);
                StageManager.getInstance().getTracker().addDelivered(packet);
            }
        }

        for (Packet packet : delivered) {
            packetsOnWire.remove(packet);
            toPort.setOccupied(false);
            toPort.getParentNode().receivePacket(packet);
        }
    }
    public void insertBendPointAt(Vector2D point, int index) {
        if (bendPoints.size() < bendableSlots && index >= 0 && index <= bendPoints.size()) {
            bendPoints.add(index, point);
        }
    }

}
