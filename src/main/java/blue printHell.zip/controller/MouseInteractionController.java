// ✅ نسخه نهایی MouseInteractionController با رفع باگ‌های منطقی و پشتیبانی از خم (Bend Point)
package controller;

import model.Port;
import model.Wire;
import util.Constants;
import util.Vector2D;
import view.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public class MouseInteractionController {
    private final WireBuilder wireBuilder;
    private final GamePanel gamePanel;
    private final GameStageView gameStageView;

    private int nextDropX = 400;
    private int nextDropY = 300;
    private final int DROP_OFFSET = 100;

    private SystemNodeView draggedNode = null;
    private Point dragOffset = null;

    // 🆕 برای درج خم
    private Wire targetWireForBend = null;
    private int bendInsertIndex = -1;
    private boolean isDraggingBend = false;

    public MouseInteractionController(WireBuilder wireBuilder, GamePanel gamePanel) {
        this.wireBuilder = wireBuilder;
        this.gamePanel = gamePanel;
        this.gameStageView = gamePanel.getGameStageView();
    }

    public void handleMousePressed(MouseEvent e) {
        Point click = e.getPoint();

        // 🧹 پاک‌سازی متغیرهای خم قبلی
        targetWireForBend = null;
        bendInsertIndex = -1;
        isDraggingBend = false;

        // 🎯 بررسی کلیک روی سیم برای درج خم
        WireView wireView = gameStageView.findWireNear(click);
        if (wireView != null) {
            Wire wire = wireView.getWire();
            Vector2D clickPos = new Vector2D(click.x, click.y);
            int segmentIndex = findClosestSegmentIndex(clickPos, wire);
            if (segmentIndex >= 0 && wire.getRemainingBendSlots() > 0) {
                targetWireForBend = wire;
                bendInsertIndex = segmentIndex;
                dragOffset = click;
                return; // ❗ مانع بررسی درگ نود می‌شود
            }
        }

        // 🎯 شروع سیم‌کشی از پورت خروجی
        Port clickedPort = gamePanel.findPortAt(click);
        if (clickedPort != null && clickedPort.getType() == Port.PortType.OUTPUT) {
            wireBuilder.startDraggingFrom(clickedPort);
            dragOffset = click;
            return;
        }

        if (e.getButton() == MouseEvent.BUTTON3) {
            Wire targetWire = gamePanel.findWireNear(click);
            if (targetWire != null) {
                wireBuilder.getWireManager().removeWire(targetWire);
                gamePanel.repaint();
                return;
            }
        }

        // کلیک روی پنل نودها
        NodePalettePanel palette = gameStageView.getNodePalettePanel();
        if (palette.getBounds().contains(click)) {
            Point localClick = SwingUtilities.convertPoint(gamePanel, click, palette);
            for (SystemNodeView view : palette.getAvailableNodes()) {
                Rectangle bounds = new Rectangle(50, (int) view.getNode().getPosition().getY(),
                        Constants.NODE_WIDTH, Constants.NODE_HEIGHT);
                if (bounds.contains(localClick)) {
                    palette.removeNode(view);
                    gameStageView.addNodeToStage(view);
                    view.setBounds(nextDropX, nextDropY, Constants.NODE_WIDTH, Constants.NODE_HEIGHT);
                    view.getNode().setPosition(new Vector2D(nextDropX, nextDropY));
                    draggedNode = view;
                    dragOffset = new Point(click.x - nextDropX, click.y - nextDropY);
                    nextDropX += DROP_OFFSET;
                    nextDropY += DROP_OFFSET;
                    gamePanel.repaint();
                    return;
                }
            }
        }

        cancelWireDrawing();
        for (SystemNodeView nodeView : gamePanel.getSystemNodeViews()) {
            Rectangle bounds = nodeView.getBounds();
            if (bounds.contains(click)) {
                draggedNode = nodeView;
                dragOffset = new Point(click.x - bounds.x, click.y - bounds.y);
                gamePanel.getSystemNodeViews().forEach(n -> n.setSelected(false));
                nodeView.setSelected(true);
                gamePanel.repaint();
                return;
            }
        }
    }

    public void handleMouseDragged(MouseEvent e) {
        if (targetWireForBend != null && bendInsertIndex >= 0) {
            isDraggingBend = true;
            gamePanel.repaint();
            return;
        }

        if (draggedNode != null && dragOffset != null) {
            int newX = e.getX() - dragOffset.x;
            int newY = e.getY() - dragOffset.y;
            draggedNode.setLocation(newX, newY);
            draggedNode.getNode().setPosition(new Vector2D(newX, newY));
            draggedNode.moveTo(newX, newY);
            gamePanel.repaint();
        }

        if (wireBuilder.isActive()) {
            wireBuilder.onMouseMove(new Vector2D(e.getX(), e.getY()));
            gamePanel.repaint();
        }
    }

    public void handleMouseReleased(MouseEvent e) {
        gameStageView.addNodeToStage(draggedNode);
        draggedNode = null;
        dragOffset = null;

        if (wireBuilder.isActive()) {
            Port target = gamePanel.findPortAt(e.getPoint());
            if (target != null) {
                wireBuilder.finishDraggingTo(target);
            } else {
                wireBuilder.cancel();
            }
            gamePanel.repaint();
        }

        if (isDraggingBend && targetWireForBend != null && bendInsertIndex >= 0) {
            Vector2D releasePos = new Vector2D(e.getX(), e.getY());
            targetWireForBend.insertBendPointAt(releasePos, bendInsertIndex + 1);
            System.out.println("🔴 خم اضافه شد در سگمنت: " + bendInsertIndex);
            gamePanel.repaint();
        }

        targetWireForBend = null;
        bendInsertIndex = -1;
        isDraggingBend = false;
    }

    public void handleMouseMoved(MouseEvent e) {
        if (wireBuilder.isActive()) {
            wireBuilder.onMouseMove(new Vector2D(e.getX(), e.getY()));
            gamePanel.repaint();
        }
    }

    public void cancelWireDrawing() {
        if (wireBuilder.isActive()) {
            wireBuilder.cancel();
            gamePanel.repaint();
        }
    }

    public WireBuilder getWireBuilder() {
        return wireBuilder;
    }

    private int findClosestSegmentIndex(Vector2D clickPos, Wire wire) {
        double minDist = Double.MAX_VALUE;
        int closestSegment = -1;
        var points = wire.getAllControlPoints();
        for (int i = 0; i < points.size() - 1; i++) {
            double dist = distancePointToSegment(clickPos.toPoint(), points.get(i).toPoint(), points.get(i + 1).toPoint());
            if (dist < Constants.WIRE_HITBOX_RADIUS && dist < minDist) {
                minDist = dist;
                closestSegment = i;
            }
        }
        return closestSegment;
    }

    private double distancePointToSegment(Point p, Point a, Point b) {
        double px = b.x - a.x;
        double py = b.y - a.y;
        double norm = px * px + py * py;
        if (norm == 0) return a.distance(p);
        double u = ((p.x - a.x) * px + (p.y - a.y) * py) / norm;
        u = Math.max(0, Math.min(1, u));
        double x = a.x + u * px;
        double y = a.y + u * py;
        return Point.distance(x, y, p.x, p.y);
    }
}
